import{bs as e,ad as s}from"./dependencies-Cdi4Awgm.js";function n(...n){return e(s(n))}export{n as c};
